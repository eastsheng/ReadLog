from distutils.core import setup

setup(
name         = 'ReadLog',
version      = '1.0.1',
py_modules   = ['ReadLog'],
author       = 'CHENDONGSHENG',
author_email = 'eastsheng@hotmail.com',
url          = 'https://github.com/eastsheng',
description  = 'Read lammps output file or log file'
)
